import React from 'react';

const Confirm = () => {
  return (
    <div>
      <h2>Confirmation</h2>
      <p>Your ticket has been submitted for further investigation.</p>
    
    </div>
  );
};

export default Confirm;
